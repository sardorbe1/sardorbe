package com.amigoscode;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MyFrame extends JFrame implements ActionListener {

             JTextField tf1, tf2, tf3;
        JButton b1, b2, b3, b4;
        JLabel l1;
        private Object word;

        MyFrame() {

            l1=new JLabel("calculator");
            l1.setBounds(80,50,100,30);
            l1.setVisible(true);
            tf1 = new JTextField();
            tf1.setBounds(250, 50, 150, 20);
            tf2 = new JTextField();
            tf2.setBounds(250, 100, 150, 20);
            tf3 = new JTextField();
            tf3.setBounds(250, 150, 150, 20);
            tf3.setEditable(false);
            b1 = new JButton("+");
            b1.setBounds(100,200, 50, 50);
            b2 = new JButton("-");
            b2.setBounds(180,200,50,50);
            b3 = new JButton("*");
            b3.setBounds(250,200,50,50);
            b4 = new JButton("/");
            b4.setBounds(320,200,50,50);
            b1.addActionListener(this);
            b2.addActionListener(this);
            b3.addActionListener(this);
            b4.addActionListener(this);
            add(l1);
            add(tf1);
            add(tf2);
            add(tf3);
            add(b1);
            add(b2);
            add(b3);
            add(b4);
            setSize(500,400);
            setLayout(null);
            setVisible(true);
        }



    @Override
    public void actionPerformed(ActionEvent e) {
        String s1 = tf1.getText();
        String s2 = tf2.getText();
        int a = Integer.parseInt(s1);
        int b = Integer.parseInt(s2);
        int c = 0;
        if (e.getSource() == b1){
            c = a + b;
        }
        else if (e.getSource() == b2){
            c = a - b;
        }
        else if (e.getSource() == b3){
            c = a * b;
        }
        else if (e.getSource() == b4){
            c = a / b;
        }
        String result = String.valueOf(c);
        tf3.setText(result);
    }
}
